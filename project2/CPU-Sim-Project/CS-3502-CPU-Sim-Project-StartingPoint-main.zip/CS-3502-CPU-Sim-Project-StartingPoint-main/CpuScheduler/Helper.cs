﻿namespace CpuScheduler
{
    public static class Helper
    {
        public static string QuantumTime { get; set; }
    }
}
